<?php


class Schema_mydb extends MY_Controller {

    function __construct() {
        $this->pathclass = basename(dirname(__FILE__));
        parent::__construct();
        $this->title = 'Permintaan Sample';
    }

    public function index() {
        $this->data['url_create_database'] = site_url($this->controller . '/insert_mydb');
        parent::index();
        
    }

    public function home_create_code() {
        $this->data['url_grid'] = site_url($this->controller . "/grid_public");
        $this->load->view($this->view . '/home_create_code', $this->data);
    }

    public function backup_database() {
		$this->load->dbutil();
        $this->load->helper('file');
		$config = array(
			'format'	=> 'zip',
			'filename'	=> 'lessential.sql'
		);
		
		$backup =& $this->dbutil->backup($config);
		$save = FCPATH.'backup_db/backup-'.date("Y-m-d H-i-s").'-db.zip';
        write_file($save, $backup);
    }
    
    public function backup_code(){
            $this->load->library('zip');
            $filename = "backup_app_".date("Y-m-d His").".zip";
            $path = 'application';
            $this->zip->read_dir($path);
            $this->zip->archive(FCPATH.'backup_code/'.$filename);
            $this->zip->download($filename);
    }


    function insert_mydb() {
        $post = $this->input->post();
        $mydb   = $post['mydb'];
            $record = array(
                "name_mydb" => $post['mydb']
            );
        if ($checkdata > 0 ){
            $valid = true;
            $message = "Update Data success";
        } else {
            $this->create_database($mydb);
            $this->modeldata->insertdata($record);
            $valid = false;
            $message = "Create Database success";
        }

        $jsonmsg = array("valid" => true, "msg" => "$message");
            echo json_encode($jsonmsg);
    }

     function create_database($mydb) {
        $this->load->dbforge();

        if ($this->dbforge->create_database("$mydb"))
        {
            echo "Update Data success";
        }

       
    }


}
