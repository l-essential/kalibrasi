<?php
class Formula_2 extends MY_Controller {

    // public $noview = 0;

     function __construct() {
          $this->pathclass = basename(dirname(__FILE__));
        parent::__construct();
        $this->title ="Konsep Produk Baru";
      
    }
}