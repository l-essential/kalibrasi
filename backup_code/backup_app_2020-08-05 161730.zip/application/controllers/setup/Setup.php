<?php

class Setup extends MY_Controller {

    function __construct() {
        $this->pathclass = basename(dirname(__FILE__));
        parent::__construct();
       
    }

    public function index() {
        $this->data['url_create_database'] = site_url($this->controller . '/create_database');
        parent::index();
        
    }

    function create_database() {
        $this->load->dbforge();
        $param = $this->input->post();
        $database = $param['database'];

        if ($this->dbforge->create_database("$database"))
        {
            echo 'Database created!';
        }

    }

      

}
